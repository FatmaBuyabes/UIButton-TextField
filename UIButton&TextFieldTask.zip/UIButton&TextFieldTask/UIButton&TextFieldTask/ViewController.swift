//
//  ViewController.swift
//  UIButton&TextFieldTask
//
//  Created by Fatma Buyabes on 28/02/2024.
//

import UIKit
import SnapKit
class ViewController: UIViewController {

    var imageView = UIImageView()
    let myButton = UIButton(type: .system)
    let myTextField = UITextField()
    var selectedImg = ""
    
    
    override func viewDidLoad() {
        
        view.backgroundColor = .white
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        subViews()
        autoLayout()
        setUpUi()
        
        myButton.addTarget(self, action: #selector(saveButton), for: .touchUpInside)
            
        }
    
    func subViews(){
        view.addSubview(imageView)
        view.addSubview(myButton)
        view.addSubview(myTextField)
    }
    
    func setUpUi(){
        
        //image
        imageView.image = UIImage(named: "")
        imageView.contentMode = .scaleAspectFit
        //imageView.layer.cornerRadius = 30
        //Button
        myButton.setTitle("Send", for: .normal) //why normal ?
        myButton.backgroundColor = .lightGray
        myButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        myButton.layer.cornerRadius = 10
        myButton.layer.borderWidth = 1
        myButton.layer.borderColor = UIColor.lightGray.cgColor
        myButton.tintColor = .white
        
        
        
        //TextField
        myTextField.placeholder = "dolphin, penguin, or kitten"  // text for the user
        myTextField.font = UIFont.systemFont(ofSize: 17)
        myTextField.textAlignment = .center
        myTextField.layer.backgroundColor = UIColor.clear.cgColor
        myTextField.layer.borderWidth = 1
        myTextField.layer.borderColor = UIColor.lightGray.cgColor
        //myTextField.keyboardType = .numberPad  if i want to amke the keyboard only numbers
        //myTextField.text = "Hello"
        
        
    }
    func autoLayout(){
        imageView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(myTextField).offset(-60)
            make.width.height.equalTo(250)
            
        }
        myTextField.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(myButton.snp.top).offset(-20)
            make.width.equalTo(250)
            make.height.equalTo(40)
        }
        myButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview()
            make.width.equalTo(100)
            make.height.equalTo(40)
        }
        
        
        
    }
   @objc func saveButton()  // help by Awdhah 🤍
    {
        selectedImg = myTextField.text ?? ""
        imageView.image = UIImage(named: selectedImg)

    }


}

